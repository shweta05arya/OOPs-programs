class SimpleProgram {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int sum = a + b;

        System.out.println("Value of a: " + a);
        System.out.println("Value of b: " + b);
        System.out.println("Sum: " + sum);
    }
}
