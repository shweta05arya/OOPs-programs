class StudentDetails {
    public static void main(String[] args) {
        System.out.println("Name: Shweta Arya");
        System.out.println("Course: B.Tech");
        System.out.println("Subject: Java Programming");
    }
}
